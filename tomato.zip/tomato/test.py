rows, cols = (3, 5) 
arr = [[0 for i in range(1)] for j in range(rows)]
print(arr)