# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.12
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PIL import Image
import io

class Ui_MainWindow(QtWidgets.QMainWindow):
    imageName = None
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(709, 379)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.graphicsView = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(20, 30, 321, 221))

        self.graphicsView.setObjectName("graphicsView")
        self.graphicsView_2 = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView_2.setGeometry(QtCore.QRect(360, 30, 321, 221))
        self.graphicsView_2.setObjectName("graphicsView_2")

        self.loadButton = QtWidgets.QPushButton(self.centralwidget)
        self.loadButton.setGeometry(QtCore.QRect(170, 270, 113, 41))
        self.loadButton.setObjectName("loadButton")
        self.loadButton.clicked.connect(self.load)

        self.horizontalButton = QtWidgets.QPushButton(self.centralwidget)
        self.horizontalButton.setGeometry(QtCore.QRect(300, 270, 113, 41))
        self.horizontalButton.setObjectName("horizontalButton")
        self.horizontalButton.clicked.connect(self.horizontal)

        self.vertikalButton = QtWidgets.QPushButton(self.centralwidget)
        self.vertikalButton.setGeometry(QtCore.QRect(430, 270, 113, 41))
        self.vertikalButton.setObjectName("vertikalButton")
        self.vertikalButton.clicked.connect(self.vertikal)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 709, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.loadButton.setText(_translate("MainWindow", "Load"))
        self.horizontalButton.setText(_translate("MainWindow", "Horizontal"))
        self.vertikalButton.setText(_translate("MainWindow", "Vertikal"))

    def load(self):
        fname = QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/PraktikumSegmentasi/')[0]
        self.scene = QtWidgets.QGraphicsScene()
        self.imageName = QtGui.QImage(fname)
        self.scene.addPixmap(QtGui.QPixmap.fromImage(self.imageName))
        self.graphicsView.setScene(self.scene)
        self.graphicsView.fitInView(self.scene.itemsBoundingRect())

    def horizontal(self):
        image = self.imageName
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        pil_im.convert('RGB')
        width, height = pil_im.size
        for x in range(width):
            for y in range(height):
                sum_wr = 0
                sum_wg = 0
                sum_wb = 0
                aa = 0
                k = [-1, -1, -1, 2, 2, 2, -1, -1, -1]
                if (x > 0 and y> 0) and (x < width and y < height):
                    count = 0
                    for i in range(-1, 2):
                        for j in range(-1, 2):
                            r, g, b, a = QtGui.QColor(image.pixel(i ,j)).getRgb()
                            wr = k[count] * r
                            wg = k[count] * g
                            wb = k[count] * b
                            sum_wr += wr
                            sum_wg += wg
                            sum_wb + wb
                            aa = a
                            count += 1
                rr = sum_wr
                gg = sum_wg
                bb = sum_wb
                if rr > 255:
                    rr = 255
                if rr < 0 :
                    rr = 0
                if gg > 255:
                    gg = 255
                if gg < 0:
                    gg = 0
                if bb > 255:
                    bb = 255
                if bb < 0:
                    bb = 0
                image.setPixel(x, y, QtGui.QColor(rr, gg, bb, aa).rgb())
        self.showImage(QtGui.QPixmap.fromImage(image))
                            

    def vertikal(self):
        image = self.imageName
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        pil_im.convert('RGB')
        width, height = pil_im.size
        for x in range(width):
            for y in range(height):
                sum_wr = 0
                sum_wg = 0
                sum_wb = 0
                aa = 0
                k = [-1, 2, -1, -1, 2, -1, -1, 2, -1]
                if (x > 0 and y> 0) and (x < width and y < height):
                    count = 0
                    for i in range(-1, 2):
                        for j in range(-1, 2):
                            r, g, b, a = QtGui.QColor(image.pixel(i ,j)).getRgb()
                            wr = k[count] * r
                            wg = k[count] * g
                            wb = k[count] * b
                            sum_wr += wr
                            sum_wg += wg
                            sum_wb + wb
                            aa = a
                            count += 1
                rr = sum_wr
                gg = sum_wg
                bb = sum_wb
                if rr > 255:
                    rr = 255
                if rr < 0 :
                    rr = 0
                if gg > 255:
                    gg = 255
                if gg < 0:
                    gg = 0
                if bb > 255:
                    bb = 255
                if bb < 0:
                    bb = 0
                image.setPixel(x, y, QtGui.QColor(rr, gg, bb, aa).rgb())
        self.showImage(QtGui.QPixmap.fromImage(image))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
