from PyQt5 import QtCore, QtGui, QtWidgets
import pytesseract
import cv2


class UiMainWindow(QtWidgets.QMainWindow):
    image_save = None

    def convert(self):
        # Convert to gray
        img = cv2.cvtColor(self.image_save, cv2.COLOR_BGR2GRAY)

        # Recognize text with tesseract for python
        data = pytesseract.image_to_data(img)
        result = pytesseract.image_to_string(img, lang="eng", config='-psm 10')
        print(data)
        self.textBrowser.setText(result)

    def load_image(self):
        file_name = QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/uas')[0]
        self.image_save = cv2.imread(file_name)  # QtGui.QImage(file_name)
        scene = QtWidgets.QGraphicsScene()
        scene.addPixmap(QtGui.QPixmap.fromImage(self.cv_image_to_qimage(self.image_save)))
        self.graphicsView.setScene(scene)
        self.graphicsView.fitInView(scene.itemsBoundingRect())

    def cv_image_to_qimage(self, cv_image):
        height, width, channel = cv_image.shape
        return QtGui.QImage(cv_image.data, width, height, 3 * width, QtGui.QImage.Format_RGB888).rgbSwapped()

    def setup_ui(self, main_window):
        main_window.setObjectName("main_window")
        main_window.resize(544, 296)
        self.central_widget = QtWidgets.QWidget(main_window)
        self.central_widget.setObjectName("central_widget")
        self.open_image_button = QtWidgets.QPushButton(self.central_widget)
        self.open_image_button.clicked.connect(self.load_image)
        self.open_image_button.setGeometry(QtCore.QRect(10, 10, 87, 29))
        self.open_image_button.setObjectName("open_image_button")
        self.detect_button = QtWidgets.QPushButton(self.central_widget)
        self.detect_button.clicked.connect(self.convert)
        self.detect_button.setGeometry(QtCore.QRect(100, 10, 87, 29))
        self.detect_button.setObjectName("detect_button")
        self.graphicsView = QtWidgets.QGraphicsView(self.central_widget)
        self.graphicsView.setGeometry(QtCore.QRect(10, 50, 256, 192))
        self.graphicsView.setObjectName("graphicsView")
        self.label = QtWidgets.QLabel(self.central_widget)
        self.label.setGeometry(QtCore.QRect(280, 50, 54, 17))
        self.label.setObjectName("label")
        self.textBrowser = QtWidgets.QTextBrowser(self.central_widget)
        self.textBrowser.setGeometry(QtCore.QRect(280, 70, 256, 171))
        self.textBrowser.setObjectName("textBrowser")
        main_window.setCentralWidget(self.central_widget)
        self.menubar = QtWidgets.QMenuBar(main_window)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 544, 23))
        self.menubar.setObjectName("menubar")
        main_window.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(main_window)
        self.statusbar.setObjectName("statusbar")
        main_window.setStatusBar(self.statusbar)

        self.re_translate_ui(main_window)
        QtCore.QMetaObject.connectSlotsByName(main_window)

    def re_translate_ui(self, main_window):
        _translate = QtCore.QCoreApplication.translate
        main_window.setWindowTitle(_translate("main_window", "Pengenalan Citra Diam"))
        self.open_image_button.setText(_translate("main_window", "Open Image"))
        self.detect_button.setText(_translate("main_window", "Detect"))
        self.label.setText(_translate("main_window", "Result:"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    main_window = QtWidgets.QMainWindow()
    ui = UiMainWindow()
    ui.setup_ui(main_window)
    main_window.show()
    sys.exit(app.exec_())
