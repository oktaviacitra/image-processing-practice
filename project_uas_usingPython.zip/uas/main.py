# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'style.ui'
#
# Created by: PyQt5 UI code generator 5.8.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from subprocess import Popen
import os


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(445, 278)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(0, 0, 441, 61))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.seleksi_warna_button = QtWidgets.QPushButton(self.centralwidget)
        self.seleksi_warna_button.setGeometry(QtCore.QRect(40, 90, 131, 29))
        self.seleksi_warna_button.setObjectName("seleksi_warna_button")
        self.seleksi_warna_button.clicked.connect(lambda: self.link(3))

        self.fitur_warna_button = QtWidgets.QPushButton(self.centralwidget)
        self.fitur_warna_button.setGeometry(QtCore.QRect(40, 130, 131, 29))
        self.fitur_warna_button.setObjectName("fitur_warna_button")
        self.fitur_warna_button.clicked.connect(lambda: self.link(1))

        self.fitur_bentuk_button = QtWidgets.QPushButton(self.centralwidget)
        self.fitur_bentuk_button.setGeometry(QtCore.QRect(40, 170, 131, 29))
        self.fitur_bentuk_button.setObjectName("fitur_bentuk_button")
        self.fitur_bentuk_button.clicked.connect(lambda: self.link(2))

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 445, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow",
                                      "<html><head/><body><p>DEMO UAS<br>PRAKTIKUM PENGOLAHAN CITRA</p></body></html>"))
        self.seleksi_warna_button.setText(_translate("MainWindow", "Seleksi Warna"))
        self.fitur_warna_button.setText(_translate("MainWindow", "Fitur Warna (Tomat)"))
        self.fitur_bentuk_button.setText(_translate("MainWindow", "Fitur Bentuk (Huruf)"))

    def link(self, destination=3):
        if destination == 1:
            os.system('python3 FiturWarna.py')
        elif destination == 2:
            os.system('python3 FiturBentuk.py')
        else:
            os.system('python3 ColorDetection.py')


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

