# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.12.1
#
# WARNING! All changes made in this file will be lost!

import io
from PyQt5 import QtCore, QtGui, QtWidgets
from PIL import Image
import cv2
import numpy as np
import colorsys


class Ui_MainWindow(QtWidgets.QMainWindow):
    image_name = None
    image_cv = None

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(542, 455)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pic1 = QtWidgets.QGraphicsView(self.centralwidget)
        self.pic1.setGeometry(QtCore.QRect(10, 10, 256, 192))
        self.pic1.setObjectName("pic1")
        self.pic2 = QtWidgets.QGraphicsView(self.centralwidget)
        self.pic2.setGeometry(QtCore.QRect(10, 210, 256, 192))
        self.pic2.setObjectName("pic2")
        self.pic3 = QtWidgets.QGraphicsView(self.centralwidget)
        self.pic3.setGeometry(QtCore.QRect(280, 210, 256, 192))
        self.pic3.setObjectName("pic3")
        self.distance_button = QtWidgets.QPushButton(self.centralwidget)
        self.distance_button.setGeometry(QtCore.QRect(290, 170, 231, 29))
        self.distance_button.setObjectName("distance_button")
        self.static_button = QtWidgets.QPushButton(self.centralwidget)
        self.static_button.setGeometry(QtCore.QRect(290, 130, 231, 29))
        self.static_button.setObjectName("static_button")
        self.load_button = QtWidgets.QPushButton(self.centralwidget)
        self.load_button.setGeometry(QtCore.QRect(290, 90, 231, 29))
        self.load_button.setObjectName("load_button")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(290, 20, 231, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 542, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.load_button.clicked.connect(self.load_image)
        self.static_button.clicked.connect(self.static_detection)
        self.distance_button.clicked.connect(self.distance_detection)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Color & Face Detection"))
        self.distance_button.setText(_translate("MainWindow", "Distance Detection"))
        self.static_button.setText(_translate("MainWindow", "Static Detection"))
        self.load_button.setText(_translate("MainWindow", "Load Image"))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p align=\"center\">Color &amp; Face<br>Detection</p></body></html>"))

    def static_detection(self):
        image = self.image_name
        width, height = self.get_width_height(image)
        for i in range(width):
            for j in range(height):
                r, g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                # if (102 < r < 160) and (70 < g < 100) and (0 < b > 65):  # skin color
                # if (180 < r < 255) and (180 < g < 255) and (180 < b < 255):  # bunga 1
                if (180 < r < 255) and (0 < g < 65) and (0 < b < 65):  # bunga 2
                    image.setPixel(i, j, QtGui.QColor(r, g, b, a).rgb())
                else:
                    image.setPixel(i, j, QtGui.QColor(0, 0, 0, a).rgb())
        self.show_image(QtGui.QPixmap.fromImage(image))

    def distance_detection(self):
        image = self.image_cv
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        # ini untuk kulit
        # scaleSatLower = 0.28
        # scaleSatUpper = 0.68
        # scaleSatLower = 0.18  # utama
        # scaleSatLower = 0.08
        # scaleSatUpper = 0.78  # utama

        #ini untuk bunga 1
        # sensitivity = 80
        # lower_white = [0, 0, 255 - sensitivity]
        # upper_white = [255, sensitivity, 255]

        #ini untuk bunga 2
        sensitivity = 50
        lower_white = [170, 70, 50]
        upper_white = [180, 255, 255]

        # Define 'skin color' range in HSV colorspace
        lower = np.array(lower_white, dtype="uint8")
        upper = np.array(upper_white, dtype="uint8")

        # Threshold the HSV image to get only blue color
        mask = cv2.inRange(hsv, lower, upper)

        # Bitwise-AND mask and original image
        res = cv2.bitwise_and(image, image, mask=mask)
        # res = cv2.medianBlur(res, 5)
        height, width, channel = res.shape
        bytesPerLine = 3 * width
        qImg = QtGui.QImage(res.data, width, height, bytesPerLine, QtGui.QImage.Format_RGB888).rgbSwapped()
        self.show_image2(QtGui.QPixmap.fromImage(qImg))

    def load_image(self):
        filename = QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/uas')[0]
        self.image_name = QtGui.QImage(filename)
        self.image_cv = cv2.imread(filename)
        scene = QtWidgets.QGraphicsScene()
        scene.addPixmap(QtGui.QPixmap.fromImage(self.image_name))
        self.pic1.setScene(scene)
        self.pic1.fitInView(scene.itemsBoundingRect())

    def show_image(self, pixmap):
        scene = QtWidgets.QGraphicsScene()
        scene.addPixmap(pixmap)
        self.pic2.setScene(scene)
        self.pic2.fitInView(scene.itemsBoundingRect())

    def show_image2(self, pixmap):
        scene = QtWidgets.QGraphicsScene()
        scene.addPixmap(pixmap)
        self.pic3.setScene(scene)
        self.pic3.fitInView(scene.itemsBoundingRect())

    def get_width_height(self, image):
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        pil_im.convert('RGB')
        width, height = pil_im.size
        return [width, height]


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
