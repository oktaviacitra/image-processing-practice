# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.12
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import QtChart
from PIL import Image
import io


class Ui_MainWindow(QtWidgets.QMainWindow):
    image_1 = None
    image_2 = None
    image_3 = None
    gn = [None] * 384
    h = [[[None] * 384] * 4]
    hs = [[[None] * 384] * 4]

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1440, 900)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.graphicsView = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(20, 20, 221, 151))
        self.graphicsView.setObjectName("graphicsView")
        self.graphicsView_2 = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView_2.setGeometry(QtCore.QRect(20, 180, 221, 151))
        self.graphicsView_2.setObjectName("graphicsView_2")
        self.graphicsView_3 = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView_3.setGeometry(QtCore.QRect(20, 340, 221, 151))
        self.graphicsView_3.setObjectName("graphicsView_3")
        self.chartview = QtChart.QChartView(self.centralwidget)
        self.chartview.setGeometry(QtCore.QRect(260, 10, 981, 171))
        self.chartview.setObjectName("chartview")
        self.chartview_2 = QtChart.QChartView(self.centralwidget)
        self.chartview_2.setGeometry(QtCore.QRect(260, 170, 981, 171))
        self.chartview_2.setObjectName("chartview_2")
        self.chartview_3 = QtChart.QChartView(self.centralwidget)
        self.chartview_3.setGeometry(QtCore.QRect(260, 330, 981, 171))
        self.chartview_3.setObjectName("chartview_3")
        self.chartview_4 = QtChart.QChartView(self.centralwidget)
        self.chartview_4.setGeometry(QtCore.QRect(260, 490, 981, 171))
        self.chartview_4.setObjectName("chartview_4")
        self.graphicsView_4 = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView_4.setGeometry(QtCore.QRect(20, 500, 221, 151))
        self.graphicsView_4.setObjectName("graphicsView_4")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(1260, 0, 161, 821))
        self.label.setText("")
        self.label.setObjectName("label")
        self.chartview_5 = QtChart.QChartView(self.centralwidget)
        self.chartview_5.setGeometry(QtCore.QRect(260, 660, 981, 171))
        self.chartview_5.setObjectName("chartview_5")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1440, 22))
        self.menubar.setObjectName("menubar")
        self.menuFile = QtWidgets.QMenu(self.menubar)
        self.menuFile.setObjectName("menuFile")
        self.menuLoad = QtWidgets.QMenu(self.menuFile)
        self.menuLoad.setObjectName("menuLoad")
        self.menuHistogram = QtWidgets.QMenu(self.menuFile)
        self.menuHistogram.setObjectName("menuHistogram")
        self.menuRGB = QtWidgets.QMenu(self.menuHistogram)
        self.menuRGB.setObjectName("menuRGB")
        self.menuIntersection = QtWidgets.QMenu(self.menuHistogram)
        self.menuIntersection.setObjectName("menuIntersection")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.actionPicture_1 = QtWidgets.QAction(MainWindow)
        self.actionPicture_1.setObjectName("actionPicture_1")
        self.actionPicture_1.triggered.connect(self.open_image_1)

        self.actionPicture_2 = QtWidgets.QAction(MainWindow)
        self.actionPicture_2.setObjectName("actionPicture_2")
        self.actionPicture_2.triggered.connect(self.open_image_2)

        self.actionPicture_3 = QtWidgets.QAction(MainWindow)
        self.actionPicture_3.setObjectName("actionPicture_3")
        self.actionPicture_3.triggered.connect(self.open_image_3)

        self.actionPicture_4 = QtWidgets.QAction(MainWindow)
        self.actionPicture_4.setObjectName("actionPicture_4")
        self.actionPicture_4.triggered.connect(self.open_image_4)

        self.actionChart_1_histogram_rgb = QtWidgets.QAction(MainWindow)
        self.actionChart_1_histogram_rgb.setObjectName("actionChart_1_histogram_rgb")
        self.actionChart_1_histogram_rgb.triggered.connect(self.histogram_rgb_1)

        self.actionChart_2_histogram_rgb = QtWidgets.QAction(MainWindow)
        self.actionChart_2_histogram_rgb.setObjectName("actionChart_2_histogram_rgb")
        self.actionChart_2_histogram_rgb.triggered.connect(self.histogram_rgb_2)

        self.actionChart_3_histogram_rgb = QtWidgets.QAction(MainWindow)
        self.actionChart_3_histogram_rgb.setObjectName("actionChart_3_histogram_rgb")
        self.actionChart_3_histogram_rgb.triggered.connect(self.histogram_rgb_3)

        self.actionChart_4_histogram_rgb = QtWidgets.QAction(MainWindow)
        self.actionChart_4_histogram_rgb.setObjectName("actionChart_4_histogram_rgb")
        self.actionChart_4_histogram_rgb.triggered.connect(self.histogram_rgb_4)

        self.actionChart_1_histogram_intersection = QtWidgets.QAction(MainWindow)
        self.actionChart_1_histogram_intersection.setObjectName("actionChart_1_histogram_intersection")
        self.actionChart_1_histogram_intersection.triggered.connect(self.histogram_intersection_1)

        self.actionChart_2_histogram_intersection = QtWidgets.QAction(MainWindow)
        self.actionChart_2_histogram_intersection.setObjectName("actionChart_2_histogram_intersection")
        self.actionChart_2_histogram_intersection.triggered.connect(self.histogram_intersection_2)

        self.actionChart_3_histogram_intersection = QtWidgets.QAction(MainWindow)
        self.actionChart_3_histogram_intersection.setObjectName("actionChart_3_histogram_intersection")
        self.actionChart_3_histogram_intersection.triggered.connect(self.histogram_intersection_3)

        self.actionChart_4_histogram_intersection = QtWidgets.QAction(MainWindow)
        self.actionChart_4_histogram_intersection.setObjectName("actionChart_4_histogram_intersection")
        self.actionChart_4_histogram_intersection.triggered.connect(self.histogram_intersection_4)

        self.actionMatching = QtWidgets.QAction(MainWindow)
        self.actionMatching.setObjectName("actionMatching")
        self.actionMatching.triggered.connect(self.matching)

        self.actionIntersection_2 = QtWidgets.QAction(MainWindow)
        self.actionIntersection_2.setObjectName("actionIntersection_2")
        self.actionIntersection_2.triggered.connect(self.intersection)

        self.menuLoad.addAction(self.actionPicture_1)
        self.menuLoad.addAction(self.actionPicture_2)
        self.menuLoad.addAction(self.actionPicture_3)
        self.menuLoad.addAction(self.actionPicture_4)
        self.menuRGB.addAction(self.actionChart_1_histogram_rgb)
        self.menuRGB.addAction(self.actionChart_2_histogram_rgb)
        self.menuRGB.addAction(self.actionChart_3_histogram_rgb)
        self.menuRGB.addAction(self.actionChart_4_histogram_rgb)
        self.menuIntersection.addAction(self.actionChart_1_histogram_intersection)
        self.menuIntersection.addAction(self.actionChart_2_histogram_intersection)
        self.menuIntersection.addAction(self.actionChart_3_histogram_intersection)
        self.menuIntersection.addAction(self.actionChart_4_histogram_intersection)
        self.menuHistogram.addAction(self.menuRGB.menuAction())
        self.menuHistogram.addAction(self.menuIntersection.menuAction())
        self.menuFile.addAction(self.menuLoad.menuAction())
        self.menuFile.addAction(self.menuHistogram.menuAction())
        self.menuFile.addAction(self.actionMatching)
        self.menuFile.addAction(self.actionIntersection_2)
        self.menubar.addAction(self.menuFile.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.menuFile.setTitle(_translate("MainWindow", "File"))
        self.menuLoad.setTitle(_translate("MainWindow", "Load"))
        self.menuHistogram.setTitle(_translate("MainWindow", "Histogram"))
        self.menuRGB.setTitle(_translate("MainWindow", "RGB"))
        self.menuIntersection.setTitle(_translate("MainWindow", "Intersection"))
        self.actionPicture_1.setText(_translate("MainWindow", "Picture 1"))
        self.actionPicture_2.setText(_translate("MainWindow", "Picture 2"))
        self.actionPicture_3.setText(_translate("MainWindow", "Picture 3"))
        self.actionChart_1_histogram_rgb.setText(_translate("MainWindow", "Chart 1"))
        self.actionChart_2_histogram_rgb.setText(_translate("MainWindow", "Chart 2"))
        self.actionChart_3_histogram_rgb.setText(_translate("MainWindow", "Chart 3"))
        self.actionChart_1_histogram_intersection.setText(_translate("MainWindow", "Chart 1"))
        self.actionChart_2_histogram_intersection.setText(_translate("MainWindow", "Chart 2"))
        self.actionChart_3_histogram_intersection.setText(_translate("MainWindow", "Chart 3"))
        self.actionMatching.setText(_translate("MainWindow", "Matching"))
        self.actionIntersection_2.setText(_translate("MainWindow", "Intersection"))
        self.actionPicture_4.setText(_translate("MainWindow", "Picture 4"))
        self.actionChart_4_histogram_rgb.setText(_translate("MainWindow", "Chart 4"))
        self.actionChart_4_histogram_intersection.setText(_translate("MainWindow", "Chart 4"))
        self.label.setText(_translate("MainWindow", ""))

    def open_image_1(self):
        file_name = \
        QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/uas')[0]
        self.scene = QtWidgets.QGraphicsScene()
        self.image_1 = QtGui.QImage(file_name)
        self.scene.addPixmap(QtGui.QPixmap.fromImage(self.image_1))
        self.graphicsView.setScene(self.scene)
        self.graphicsView.fitInView(self.scene.itemsBoundingRect())

    def open_image_2(self):
        file_name = \
        QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/uas')[0]
        self.scene = QtWidgets.QGraphicsScene()
        self.image_2 = QtGui.QImage(file_name)
        self.scene.addPixmap(QtGui.QPixmap.fromImage(self.image_2))
        self.graphicsView_2.setScene(self.scene)
        self.graphicsView_2.fitInView(self.scene.itemsBoundingRect())

    def open_image_3(self):
        file_name = \
        QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/uas')[0]
        self.scene = QtWidgets.QGraphicsScene()
        self.image_3 = QtGui.QImage(file_name)
        self.scene.addPixmap(QtGui.QPixmap.fromImage(self.image_3))
        self.graphicsView_3.setScene(self.scene)
        self.graphicsView_3.fitInView(self.scene.itemsBoundingRect())

    def open_image_4(self):
        file_name = \
        QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/uas')[0]
        self.scene = QtWidgets.QGraphicsScene()
        self.image_4 = QtGui.QImage(file_name)
        self.scene.addPixmap(QtGui.QPixmap.fromImage(self.image_4))
        self.graphicsView_4.setScene(self.scene)
        self.graphicsView_4.fitInView(self.scene.itemsBoundingRect())

    def buffer_image(self, image):
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        pil_im.convert('RGB')
        width, height = pil_im.size
        return image, width, height

    def histogram_rgb_1(self):
        self.h = [[0 for i in range(384)] for j in range(1)]
        image, width, height = self.buffer_image(self.image_1)
        for i in range(width):
            for j in range(height):
                r, g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                wr = int(r / 2)
                wg = int(g / 2)
                wb = int(b / 2)
                self.h[0][wr] = self.h[0][wr] + 1
                self.h[0][wg + 128] = self.h[0][wg + 128] + 1
                self.h[0][wg + 256] = self.h[0][wg + 256] + 1
        temp = []
        for i in range(384):
            temp.append(self.h[0][i])
        max_value = max(temp)
        result = []
        for i in range(384):
            result.append(110 * self.h[0][i] / max_value)
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram(dataChart)

    def histogram_rgb_2(self):
        # self.h = [[0 for i in range(384)] for j in range(1, 2)]
        for i in range(384):
            self.h[1][i] = 0
        image, width, height = self.buffer_image(self.image_2)
        for i in range(width):
            for j in range(height):
                r, g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                wr = int(r / 2)
                wg = int(g / 2)
                wb = int(b / 2)
                self.h[1][wr] = self.h[1][wr] + 1
                self.h[1][wg + 128] = self.h[1][wg + 128] + 1
                self.h[1][wg + 256] = self.h[1][wg + 256] + 1
        temp = []
        for i in range(384):
            temp.append(self.h[1][i])
        max_value = max(temp)
        result = []
        for i in range(384):
            result.append(110 * self.h[1][i] / max_value)
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram_2(dataChart)

    def histogram_rgb_3(self):
        # self.h = [[0 for i in range(384)] for j in range(2, 3)]
        for i in range(384):
            self.h[2][i] = 0
        image, width, height = self.buffer_image(self.image_3)
        for i in range(width):
            for j in range(height):
                r, g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                wr = int(r / 2)
                wg = int(g / 2)
                wb = int(b / 2)
                self.h[2][wr] = self.h[2][wr] + 1
                self.h[2][wg + 128] = self.h[2][wg + 128] + 1
                self.h[2][wg + 256] = self.h[2][wg + 256] + 1
        temp = []
        for i in range(384):
            temp.append(self.h[2][i])
        max_value = max(temp)
        result = []
        for i in range(384):
            result.append(110 * self.h[2][i] / max_value)
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram_3(dataChart)

    def histogram_rgb_4(self):
        # self.h = [[0 for i in range(384)] for j in range(3, 4)]
        for i in range(384):
            self.h[3][i] = 0
        image, width, height = self.buffer_image(self.image_4)
        for i in range(width):
            for j in range(height):
                r, g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                wr = int(r / 2)
                wg = int(g / 2)
                wb = int(b / 2)
                self.h[3][wr] = self.h[3][wr] + 1
                self.h[3][wg + 128] = self.h[3][wg + 128] + 1
                self.h[3][wg + 256] = self.h[3][wg + 256] + 1
        temp = []
        for i in range(384):
            temp.append(self.h[3][i])
        max_value = max(temp)
        result = []
        for i in range(384):
            result.append(110 * self.h[3][i] / max_value)
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram_4(dataChart)

    def histogram_intersection_1(self):
        for i in range(384):
            self.hs[0][i] = abs(self.h[0][i] - self.gn[i])
        result = []
        for i in range(384):
            result.append(self.hs[0][i])
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram(dataChart)

    def histogram_intersection_2(self):
        for i in range(384):
            self.hs[1][i] = abs(self.h[1][i] - self.gn[i])
        result = []
        for i in range(384):
            result.append(self.hs[1][i])
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram_2(dataChart)

    def histogram_intersection_3(self):
        for i in range(384):
            self.hs[2][i] = abs(self.h[2][i] - self.gn[i])
        result = []
        for i in range(384):
            result.append(self.hs[2][i])
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram_3(dataChart)

    def histogram_intersection_4(self):
        for i in range(384):
            self.hs[3][i] = abs(self.h[3][i] - self.gn[i])
        result = []
        for i in range(384):
            result.append(self.hs[3][i])
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << result[i]
        self.get_histogram_4(dataChart)

    def get_histogram(self, dataChart):
        series = QtChart.QBarSeries()
        series.append(dataChart)
        chart = QtChart.QChart()
        chart.addSeries(series)
        chart.setTitle("Histogram")
        chart.setAnimationOptions(QtChart.QChart.SeriesAnimations)
        chart.setTheme(QtChart.QChart.ChartThemeBlueCerulean)
        axis = QtChart.QValueAxis()
        chart.createDefaultAxes()
        chart.setAxisX(axis, series)
        chart.axisY(series)
        chart.legend().setVisible(True)
        chart.legend().setAlignment(QtCore.Qt.AlignBottom)
        self.chartview.setChart(chart)
        self.chartview.setRenderHint(QtGui.QPainter.Antialiasing)

    def get_histogram_2(self, dataChart):
        series = QtChart.QBarSeries()
        series.append(dataChart)
        chart = QtChart.QChart()
        chart.addSeries(series)
        chart.setTitle("Histogram")
        chart.setAnimationOptions(QtChart.QChart.SeriesAnimations)
        chart.setTheme(QtChart.QChart.ChartThemeBlueCerulean)
        axis = QtChart.QValueAxis()
        chart.createDefaultAxes()
        chart.setAxisX(axis, series)
        chart.axisY(series)
        chart.legend().setVisible(True)
        chart.legend().setAlignment(QtCore.Qt.AlignBottom)
        self.chartview_2.setChart(chart)
        self.chartview_2.setRenderHint(QtGui.QPainter.Antialiasing)

    def get_histogram_3(self, dataChart):
        series = QtChart.QBarSeries()
        series.append(dataChart)
        chart = QtChart.QChart()
        chart.addSeries(series)
        chart.setTitle("Histogram")
        chart.setAnimationOptions(QtChart.QChart.SeriesAnimations)
        chart.setTheme(QtChart.QChart.ChartThemeBlueCerulean)
        axis = QtChart.QValueAxis()
        chart.createDefaultAxes()
        chart.setAxisX(axis, series)
        chart.axisY(series)
        chart.legend().setVisible(True)
        chart.legend().setAlignment(QtCore.Qt.AlignBottom)
        self.chartview_3.setChart(chart)
        self.chartview_3.setRenderHint(QtGui.QPainter.Antialiasing)

    def get_histogram_4(self, dataChart):
        series = QtChart.QBarSeries()
        series.append(dataChart)
        chart = QtChart.QChart()
        chart.addSeries(series)
        chart.setTitle("Histogram")
        chart.setAnimationOptions(QtChart.QChart.SeriesAnimations)
        chart.setTheme(QtChart.QChart.ChartThemeBlueCerulean)
        axis = QtChart.QValueAxis()
        chart.createDefaultAxes()
        chart.setAxisX(axis, series)
        chart.axisY(series)
        chart.legend().setVisible(True)
        chart.legend().setAlignment(QtCore.Qt.AlignBottom)
        self.chartview_4.setChart(chart)
        self.chartview_4.setRenderHint(QtGui.QPainter.Antialiasing)

    def get_histogram_5(self, dataChart):
        series = QtChart.QBarSeries()
        series.append(dataChart)
        chart = QtChart.QChart()
        chart.addSeries(series)
        chart.setTitle("Histogram")
        chart.setAnimationOptions(QtChart.QChart.SeriesAnimations)
        chart.setTheme(QtChart.QChart.ChartThemeBlueCerulean)
        axis = QtChart.QValueAxis()
        chart.createDefaultAxes()
        chart.setAxisX(axis, series)
        chart.axisY(series)
        chart.legend().setVisible(True)
        chart.legend().setAlignment(QtCore.Qt.AlignBottom)
        self.chartview_5.setChart(chart)
        self.chartview_5.setRenderHint(QtGui.QPainter.Antialiasing)

    def intersection(self):
        for i in range(384):
            # self.gn[i] = min(self.h[0][i], self.h[1][i], self.h[2][i])
            self.gn[i] = self.h[0][i]
        dataChart = QtChart.QBarSet("Count")
        dataChart.setColor(QtCore.Qt.black)
        for i in range(384):
            dataChart << self.gn[i]
        self.get_histogram_5(dataChart)

    def matching(self):
        distance = []
        const = 0
        for i in range(3):
            distance[i] = 0
            for j in range(384):
                const += abs(self.hs[3][j] - self.hs[i][j])
            const /= 384
            distance[i] = const
        color = ["Hijau", "Merah", "Oranye"]
        result = None
        for i in range(3):
            result += color[i] + str(distance[i]) + "\n"
        result = result + "\nHasilnya adalah " + min(distance)
        self.label.setText(result)
        self.label.show()


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())