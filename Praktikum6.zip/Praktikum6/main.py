# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.12
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(982, 446)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.loadButton = QtWidgets.QPushButton(self.centralwidget)
        self.loadButton.setGeometry(QtCore.QRect(20, 10, 111, 32))
        self.loadButton.setObjectName("loadButton")
        self.loadButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.loadButton_2.setGeometry(QtCore.QRect(140, 10, 111, 32))
        self.loadButton_2.setObjectName("loadButton_2")
        self.histogramButton = QtWidgets.QPushButton(self.centralwidget)
        self.histogramButton.setGeometry(QtCore.QRect(260, 10, 111, 32))
        self.histogramButton.setObjectName("histogramButton")
        self.cdfButton = QtWidgets.QPushButton(self.centralwidget)
        self.cdfButton.setGeometry(QtCore.QRect(380, 10, 111, 32))
        self.cdfButton.setObjectName("cdfButton")
        self.graphicsView = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(30, 50, 451, 321))
        self.graphicsView.setObjectName("graphicsView")
        self.pdfButton = QtWidgets.QPushButton(self.centralwidget)
        self.pdfButton.setGeometry(QtCore.QRect(500, 10, 111, 32))
        self.pdfButton.setObjectName("pdfButton")
        self.chartview = QtChart.QChartView(self.centralwidget)
        self.chartview.setGeometry(QtCore.QRect(510, 40, 451, 341))
        self.chartview.setObjectName("chartview")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 982, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.loadButton.setText(_translate("MainWindow", "Load"))
        self.loadButton_2.setText(_translate("MainWindow", "Grayscale"))
        self.histogramButton.setText(_translate("MainWindow", "Histogram"))
        self.cdfButton.setText(_translate("MainWindow", "CDF"))
        self.pdfButton.setText(_translate("MainWindow", "PDF"))


from PyQt5 import QtChart


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
