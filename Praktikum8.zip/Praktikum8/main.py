# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'main.ui'
#
# Created by: PyQt5 UI code generator 5.12
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PIL import Image
import io

class Ui_MainWindow(QtWidgets.QMainWindow):
    imageName = None
    a = []
    b = []
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.graphicsView = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(20, 30, 341, 251))
        self.graphicsView.setObjectName("graphicsView")
        self.graphicsView_2 = QtWidgets.QGraphicsView(self.centralwidget)
        self.graphicsView_2.setGeometry(QtCore.QRect(380, 30, 341, 251))
        self.graphicsView_2.setObjectName("graphicsView_2")

        self.loadButton = QtWidgets.QPushButton(self.centralwidget)
        self.loadButton.setGeometry(QtCore.QRect(120, 290, 113, 32))
        self.loadButton.setObjectName("loadButton")
        self.loadButton.clicked.connect(self.load)

        self.grayscaleButton = QtWidgets.QPushButton(self.centralwidget)
        self.grayscaleButton.setGeometry(QtCore.QRect(250, 290, 113, 32))
        self.grayscaleButton.setObjectName("grayscaleButton")
        self.grayscaleButton.clicked.connect(self.grayscale)

        self.filter4nodeButton = QtWidgets.QPushButton(self.centralwidget)
        self.filter4nodeButton.setGeometry(QtCore.QRect(380, 290, 113, 32))
        self.filter4nodeButton.setObjectName("filter4nodeButton")
        self.filter4nodeButton.clicked.connect(self.filter4node)

        self.filter8nodeButton = QtWidgets.QPushButton(self.centralwidget)
        self.filter8nodeButton.setGeometry(QtCore.QRect(500, 290, 113, 32))
        self.filter8nodeButton.setObjectName("filter8nodeButton")
        self.filter8nodeButton.clicked.connect(self.filter8node)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.loadButton.setText(_translate("MainWindow", "Load"))
        self.grayscaleButton.setText(_translate("MainWindow", "Grayscale"))
        self.filter4nodeButton.setText(_translate("MainWindow", "Filter 4 Node"))
        self.filter8nodeButton.setText(_translate("MainWindow", "Filter 8 Node"))

    def load(self):
        fname = QtWidgets.QFileDialog.getOpenFileName(self, 'Open file', '/Users/oktaviacitra/ImageProcessing/Praktikum8/')[0]
        self.scene = QtWidgets.QGraphicsScene()
        self.imageName = QtGui.QImage(fname)
        self.scene.addPixmap(QtGui.QPixmap.fromImage(self.imageName))
        self.graphicsView.setScene(self.scene)
        self.graphicsView.fitInView(self.scene.itemsBoundingRect())

    def grayscale(self):
        image = self.imageName
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        im = pil_im.convert('RGB')
        matrix = (0.2, 0.5, 0.3, 0.0, 0.2, 0.5, 0.3, 0.0, 0.2, 0.5, 0.3, 0.0)
        result = im.convert('RGB',matrix)
        self.showImage(self.pil2pixmap(result))

    def showImage(self,pixmap):
        self.scene = QtWidgets.QGraphicsScene()
        self.scene.addPixmap(pixmap)
        self.graphicsView_2.setScene(self.scene)
        self.graphicsView_2.fitInView(self.scene.itemsBoundingRect())
    
    def pil2pixmap(self,im):
        if im.mode == "RGB":
            pass
        elif im.mode == "L":
            im = im.convert("RGBA")
        data = im.convert("RGBA").tobytes("raw", "RGBA")
        qim = QtGui.QImage(data, im.size[0], im.size[1], QtGui.QImage.Format_ARGB32)
        pixmap = QtGui.QPixmap.fromImage(qim)
        return pixmap

    def filter4node(self):
        r = [0, 0, 0, 0, 0]
        image = self.imageName
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        pil_im.convert('RGB')
        width, height = pil_im.size
        # for i in range(5):
        #     self.a.append(0.2)
        self.a.append(-0.5)
        self.a.append(-0.5)
        self.a.append(0)
        # self.a.append(1)
        self.a.append(0.5)
        self.a.append(0.5)
        for i in range(width):
            for j in range(height):
                r[0], g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                # if i + 1 > width - 1 or j + 1 > height - 1:
                #     self.r[2], g, b, a = 0, 0, 0, 0
                #     self.r[4], g, b, a = 0, 0, 0, 0
                # else:
                r[2], g, b, a = QtGui.QColor(image.pixel(i + 1, j)).getRgb()
                r[4], g, b, a = QtGui.QColor(image.pixel(i, j + 1)).getRgb()
                # if i - 1 < 0 or j - 1 < 0:
                #     self.r[1], g, b, a = 0, 0, 0, 0
                #     self.r[3], g, b, a = 0, 0, 0, 0
                # else:
                r[3], g, b, a = QtGui.QColor(image.pixel(i, j - 1)).getRgb()
                r[1], g, b, a = QtGui.QColor(image.pixel(i - 1, j)).getRgb()
                h = 0.0
                for k in range(5):
                    h += self.a[k] * r[k]
                xb = int(h)
                if xb < 0:
                    xb = 0
                if xb > 255:
                    xb = 255
                image.setPixel(i, j, QtGui.QColor(xb, xb, xb, a).rgb())
        self.showImage(QtGui.QPixmap.fromImage(image))
    
    def filter8node(self):
        r = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        image = self.imageName
        buffer = QtCore.QBuffer()
        buffer.open(QtCore.QBuffer.ReadWrite)
        image.save(buffer, "JPG")
        pil_im = Image.open(io.BytesIO(buffer.data()))
        pil_im.convert('RGB')
        width, height = pil_im.size
        # self.b.append(-1)
        # self.b.append(-0.5)
        # self.b.append(0)
        # self.b.append(-0.5)
        # self.b.append(0)
        # self.b.append(1)
        # self.b.append(0.5)
        # self.b.append(0)
        # self.b.append(0.5)
        # self.b.append(1)
        for i in range(9):
            if i == 4:
                self.b.append(0.2)
            else:
                self.b.append(0.1)
        for i in range(width):
            for j in range(height):
                r[0], g, b, a = QtGui.QColor(image.pixel(i - 1, j - 1)).getRgb()
                r[1], g, b, a = QtGui.QColor(image.pixel(i - 1, j)).getRgb()
                r[2], g, b, a = QtGui.QColor(image.pixel(i - 1, j + 1)).getRgb()
                r[3], g, b, a = QtGui.QColor(image.pixel(i, j - 1)).getRgb()
                r[4], g, b, a = QtGui.QColor(image.pixel(i, j)).getRgb()
                r[5], g, b, a = QtGui.QColor(image.pixel(i, j + 1)).getRgb()
                r[6], g, b, a = QtGui.QColor(image.pixel(i + 1, j - 1)).getRgb()
                r[7], g, b, a = QtGui.QColor(image.pixel(i + 1, j)).getRgb()
                r[8], g, b, a = QtGui.QColor(image.pixel(i + 1, j + 1)).getRgb()
                h = 0.0
                for k in range(9):
                    h += self.b[k] * r[k]
                xb = int(h)
                if xb < 0:
                    xb = 0
                if xb > 255:
                    xb = 255
                image.setPixel(i, j, QtGui.QColor(xb, xb, xb, a).rgb())
        self.showImage(QtGui.QPixmap.fromImage(image))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
